const DataImg = ["./img/img3.png","./img/img4.png","./img/img5.jpg","./img/img6.png","./img/img7.jpg",]

export default DataImg;