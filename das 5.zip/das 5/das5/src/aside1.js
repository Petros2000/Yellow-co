import './App.css';



function Aside1() {
  return (
    <div className="Aside1">
        <p className="aside1_p">holistic support, accountability & community for your meaningful work</p>
        <p className="aside2_p">CONNECT WITH YOURSELF, YOUR WORK, AND OTHERS</p>
        <button className="aside_btn">JOIN A GUIDANC GRUP</button>
        <iframe width="860" height="484" src="https://www.youtube.com/embed/NeRZ_tdD8KM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen className="video_1"></iframe>
    </div>
  );
}

export default Aside1;