import './App.css';



function Aside2() {
  return (
    <div className="data">
      <div className="data1">


        <div>
          <p>SAVE PRECIOUS
            TIME BY TALKING WITH
            OTHERS</p>
        </div>
        <div>
          <p>REFLECT ON WHERE
            YOU’VE BEEN & GET INTENTIONAL ABOUT WHERE YOU’RE HEADED
          </p>
          <button>Get involved</button>
        </div>
        <div>
          <p>RECIEVE GUIDANCE &
            <br></br>
            ACCOUNTABILITY
            AS YOU CREATE</p>
        </div>
      </div>
     
    </div>
  );
}

export default Aside2;