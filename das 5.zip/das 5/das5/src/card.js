import './App.css';
function Card() {
    return (
        <div className="Card">

            <div className='div1' > <img src='./img/img8.jpg'></img></div>
            <div className='div2' > <img src='./img/img9.png'></img></div>
            <div className='div3'> <img src='./img/img10.jpg'></img></div>

        </div>
    );
}

export default Card;